package com.example.login.LoginAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
