package com.example.login.LoginAuthentication.entity;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//@Entity
//@Data
//@Builder
//@Getter
//@Setter
//@Table(name="admin")
//public class Admin {
//    @Id
//    @Column(name="employee_id")
//    private int employee_id;
//    @Column(name="employee_name")
//    private String employee_name;
//    @Column(name="first_name")
//    private String first_name;
//    @Column(name="last_name")
//    private String last_name;
//    @Column(name="email_id")
//    private String email_id;


//}
